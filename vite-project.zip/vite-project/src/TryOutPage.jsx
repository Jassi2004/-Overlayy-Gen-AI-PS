import React, { useState } from "react";
import "./TryOutPage.css"; // Import your CSS file for styles
import Navbar from "./Navbar";
import axios from "axios";

const TryOutPage = () => {
  const [url, setUrl] = useState("");
  const handleInputChange = (event) => {
    setUrl(event.target.value);
  };
  const handleSubmit = async () => {
    if (url.trim() === "") {
      alert("Please enter a valid URL");
      return;
    }
    try {
      const response = await axios.post("http://localhost:8000/crawl", { url });
      console.log("Response from server:", response.data);
      // Handle the response, e.g., display success message or process data
    } catch (error) {
      console.error("Error during the POST request:", error);
      alert("There was an error processing your request.");
    }
  };

  return (
    <>
    {/* <Navbar/> */}
    <div className="navbar">
      <div className="navbar-brand">HackinTech</div>
      <nav className="navbar-links">
        <a href="#resources">Resources</a>
        <a href="#overview">Overview</a>
        <a href="#team">Team</a>
        <a href="#contact">Contact Us</a>
      </nav>
      <div className="navbar-login">
        <button>Login/Signup</button>
      </div>
    </div>

      <main className="main-content2">
        <div className="text-content">
          <h3>
            <i className="fa-solid fa-eye"></i>A.I. Never Seen Before
          </h3>
          <h2>HackinTech.AI</h2>
          <p>"Unlock Insights, One Link at a Time!"</p>
        </div>

        <div className="search-bar-container">
        <input
            type="text"
            className="search-input"
            value={url} // Bind the input value to state
            onChange={handleInputChange} // Update state on input change
            placeholder="Enter your URL (https://hackintech.com)"
          />
          <button className="search-button" onClick={handleSubmit}>
          <i className="fa-solid fa-arrow-right"></i>
          </button>
        </div>
      </main>
    </>

  );
};

export default TryOutPage;
